from django.apps import AppConfig


class DinshirenwuConfig(AppConfig):
    name = 'dinshirenwu'
