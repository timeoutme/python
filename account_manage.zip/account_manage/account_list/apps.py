from django.apps import AppConfig


class AccountListConfig(AppConfig):
    name = 'account_list'
