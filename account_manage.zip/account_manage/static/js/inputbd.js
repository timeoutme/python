var myear = window.document.getElementsByName("bod"); 
var bithy = myear[0]+"年"+myear[1]+"月"+myear[2]+"日";
window.getElementById("birthday").value = bithy;